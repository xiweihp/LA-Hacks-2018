//
//  Data.swift
//  067 - Hotel Booking
//
//  Created by Mark Moeykens on 4/14/17.
//  Copyright © 2017 Moeykens. All rights reserved.
//

import Foundation

class Data {
    class func getData() -> [SelectionModel] {
        var data = [SelectionModel]()
        data.append(SelectionModel(itemName: "int", icon_str: "123"))
        data.append(SelectionModel(itemName: "double", icon_str: "0.465"))
        data.append(SelectionModel(itemName: "string", icon_str: "abc"))
        data.append(SelectionModel(itemName: "pointer", icon_str: "0xffae"))
        data.append(SelectionModel(itemName: "array", icon_str: "[...]"))
        data.append(SelectionModel(itemName: "struct", icon_str: "{...}"))
        data.append(SelectionModel(itemName: "function", icon_str: "func{}"))
        return data
    }
}

