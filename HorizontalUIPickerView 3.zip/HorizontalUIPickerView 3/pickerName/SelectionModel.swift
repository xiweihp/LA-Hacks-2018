//
//  SelectionModel.swift
//  067 - Hotel Booking
//
//  Created by Mark Moeykens on 4/14/17.
//  Copyright © 2017 Moeykens. All rights reserved.
//

import Foundation

class SelectionModel {
    var itemName = ""
    var icon_str = ""
    
    
    init(itemName: String, icon_str: String) {
        self.itemName = itemName
        self.icon_str = icon_str
        
    }
}
