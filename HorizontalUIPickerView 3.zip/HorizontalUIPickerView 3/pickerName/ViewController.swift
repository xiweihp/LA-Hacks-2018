//
//  ViewController.swift
//  067 - Hotel Booking
//
//  Created by Mark Moeykens on 4/13/17.
//  Copyright © 2017 Moeykens. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var arrivalDayPicker: UIPickerView!
    @IBOutlet weak var datesView: UIView!
    @IBOutlet weak var totalPriceLabel: UILabel!
    @IBOutlet weak var numberOfGuestsLabel: UILabel!
    
    var rotationAngle: CGFloat!
    var selectionModelPicker: SelectionModelPicker!
    var arrivalPickerDelDataSource: MonthYearPickerView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        NotificationCenter.default.addObserver(self, selector: #selector(pickerChanged), name: .pickersChanged, object: nil)

        
        rotationAngle = -(90 * (.pi/180))
        var y = arrivalDayPicker.frame.origin.y
        arrivalDayPicker.transform = CGAffineTransform(rotationAngle: rotationAngle)
        arrivalDayPicker.frame = CGRect(x: -100, y: y, width: view.frame.width + 200, height: 100)
        
        selectionModelPicker = SelectionModelPicker()
       
        selectionModelPicker.rotationAngle = rotationAngle
        
        arrivalDayPicker.delegate = selectionModelPicker
        arrivalDayPicker.dataSource = selectionModelPicker
        arrivalDayPicker.selectRow(3, inComponent: 0, animated: true)
        
        

   }
    
    func pickerChanged(_ notification: Notification?) {
        let start = arrivalDayPicker.selectedRow(inComponent: 0)
        let dict = ["int", "double", "string", "pointer", "array", "struct", "function"]
        print(dict[start])
    }
    
    
}
