//
//  DateModePicker.swift
//  067 - Hotel Booking
//
//  Created by Mark Moeykens on 4/14/17.
//  Copyright © 2017 Moeykens. All rights reserved.
//

import UIKit

class SelectionModelPicker: NSObject {
    var modelData: [SelectionModel]!
    var rotationAngle: CGFloat!
    
    override init() {
        modelData = Data.getData()
    }
}

extension SelectionModelPicker: UIPickerViewDataSource {
    // Like number of columns
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return modelData.count
    }
}

extension SelectionModelPicker: UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, rowHeightForComponent component: Int) -> CGFloat {
        return 100
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
        
        let textColor = UIColor.white
        
        let topLabel = UILabel(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: 15))
        topLabel.text = modelData[row].itemName
        topLabel.textColor = textColor
        topLabel.textAlignment = .center
        topLabel.font = UIFont.systemFont(ofSize: 14, weight: UIFontWeightThin)
        view.addSubview(topLabel)
        
        let middleLabel = UILabel(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height))
        middleLabel.text = modelData[row].icon_str
        middleLabel.textColor = textColor
        middleLabel.textAlignment = .center
        middleLabel.font = UIFont.systemFont(ofSize: 42, weight: UIFontWeightThin)
        view.addSubview(middleLabel)
    
        view.transform = CGAffineTransform(rotationAngle: (90 * (.pi/180)))
        
        return view
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        NotificationCenter.default.post(name: .pickersChanged, object: self)
    }
}
