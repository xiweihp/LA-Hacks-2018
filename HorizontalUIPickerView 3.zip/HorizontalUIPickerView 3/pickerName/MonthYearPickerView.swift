//
//  MonthYearPickerView.swift
//  067 - Hotel Booking
//
//  Created by Mark Moeykens on 4/14/17.
//  Copyright © 2017 Moeykens. All rights reserved.
//

import UIKit

class MonthYearPickerView: UIPickerView, UIPickerViewDataSource, UIPickerViewDelegate {
    
    let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    let years = ["2017", "2018"]
    
    // MARK: - UIPickerViewDataSource
    
    // returns the number of 'columns' to display.
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    // returns the # of rows in each component
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return component == 0 ? 12 : 2
    }
    
    // MARK: - UIPickerViewDelegate
    
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        let attribute = [NSForegroundColorAttributeName: UIColor.white]
        let text =  component == 0 ? months[row] : years[row]
        
        return NSAttributedString(string: text, attributes: attribute)
    }
}
