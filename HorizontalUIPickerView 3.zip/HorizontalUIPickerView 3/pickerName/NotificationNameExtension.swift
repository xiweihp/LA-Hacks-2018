//
//  NotificationNameExtension.swift
//  067 - Hotel Booking
//
//  Created by Mark Moeykens on 4/14/17.
//  Copyright © 2017 Moeykens. All rights reserved.
//

import Foundation

extension Notification.Name {
    static let pickersChanged = NSNotification.Name("pickersChanged")
}
